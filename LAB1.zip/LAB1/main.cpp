﻿#include <iostream>
#include <cstring>
#include <limits>
#include "main.h"

using namespace std;

// Константы
const int MAX_TYPE_LENGTH = 19;     // Максимальная длина строки для типа, равна 19, чтобы позволить безопасное копирование строки и корректное завершение строки нулевым символом.
const int MAX_LENGTH = 20;          // Максимальная длина строки, может быть переопределена в классе Pin, задана на 20, чтобы дать пространство для ввода и нулевого символа.
const int MIN_DIAMETER = 0;         // Минимально допустимое значение для диаметра
const float MIN_NEEDLE_SIZE = 0.0f; // Минимально допустимый размер иглы

// Определение конструктора по умолчанию класса Pin
Pin::Pin()
{
    diameter = MIN_DIAMETER;                   // Устанавливаем диаметр в 0
    strncpy(type, "Default", MAX_TYPE_LENGTH); // Копируем строку "Default" в type, ограничивая длину
    type[MAX_TYPE_LENGTH - 1] = '\0';          // Завершаем строку нулевым символом
    needle = MIN_NEEDLE_SIZE;                  // Устанавливаем размер иглы в 0.0
    used = false;                              // Устанавливаем флаг использования в false
}

// Определение конструктора класса Pin с параметрами
Pin::Pin(int diameter, const char* type, float needle, bool used)
{
    this->diameter = diameter;                      // Устанавливаем диаметр
    strncpy(this->type, type, MAX_TYPE_LENGTH - 1); // Копируем тип, ограничивая длину
    this->type[MAX_TYPE_LENGTH - 1] = '\0';         // Завершаем строку нулевым символом
    this->needle = needle;                          // Устанавливаем размер иглы
    this->used = used;                              // Устанавливаем флаг использования
}

// Определение деструктора класса Pin
Pin::~Pin()
{
    cout << "Destructor called for Pin object" << endl; // Сообщение при вызове деструктора
}

// Определение метода Print класса Pin

void Pin::Print() const
{
    // Вывод информации об объекте Pin c использованием геттеров для доступа к данным
    cout << "Pin diameter: " << getDiameter()
        << " Type: " << getType()
        << " Needle size: " << getNeedle()
        << " Used: " << (isUsed() ? "true" : "false") << endl;
}

// Метод для установки диаметра
bool Pin::setDiameter(int dia)
{
    // Устанавливаем диаметр, если он неотрицательный
    if (dia >= MIN_DIAMETER)
    {
        diameter = dia;
        return true;
    }
    return false;
}

// Метод для установки типа
bool Pin::setType(const char* t)
{
    // Проверяем, что длина строки меньше максимального значения, и копируем тип
    if (strlen(t) < MAX_TYPE_LENGTH)
    {
        strncpy(type, t, MAX_TYPE_LENGTH - 1);
        type[MAX_TYPE_LENGTH - 1] = '\0';
        return true;
    }
    return false;
}

// Метод для установки размера иглы
bool Pin::setNeedle(float n)
{
    // Устанавливаем размер иглы, если он неотрицательный
    if (n >= MIN_NEEDLE_SIZE)
    {
        needle = n;
        return true;
    }
    return false;
}

// Метод для установки использования
bool Pin::setUsed(bool u)
{
    // Устанавливаем флаг использования
    used = u;
    return true;
}

// Определение метода Input класса Pin
void Pin::Input()
{
    int tempDiameter;
    float tempNeedle;
    char tempType[MAX_LENGTH];
    int tempUsed;

    // Ввод диаметра
    cout << "Enter Pin diameter: ";
    while (!(cin >> tempDiameter) || !setDiameter(tempDiameter))
    {
        cout << "Invalid input. Please enter a valid non-negative integer for diameter: ";
        cin.clear();                                         // Очистка потока ввода
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Игнорирование неверного ввода
    }
    cin.ignore(); // Игнорирование символа новой строки

    // Ввод типа
    std::cout << "Enter type (max " << MAX_TYPE_LENGTH - 1 << " characters): ";
    while (true) {
        std::cin.getline(tempType, MAX_TYPE_LENGTH); // Чтение строки

        // Проверка и очистка потока
        if (std::cin.fail()) {
            std::cin.clear(); // Очистить состояние потока
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Игнорировать остаточные символы новой строки
            std::cout << "Invalid input. Please enter a type with less than " << MAX_TYPE_LENGTH - 1 << " characters: ";
            continue;
        }

        if (setType(tempType)) {
            break; // Установка типа, если длина корректная
        }
        else {
            std::cout << "Invalid input. Please enter a type with less than " << MAX_TYPE_LENGTH << " characters: ";
        }
    }
    // Ввод размера иглы
    cout << "Enter needle size: ";
    while (!(cin >> tempNeedle) || !setNeedle(tempNeedle))
    {
        cout << "Invalid input. Please enter a valid floating-point number for needle size: ";
        cin.clear();                                         // Очистка потока ввода
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Игнорирование неверного ввода
    }

    // Ввод использования
    cout << "Enter if the pin is used (1 for true, 0 for false): ";
    while (!(cin >> tempUsed) || (tempUsed != 0 && tempUsed != 1))
    {
        cout << "Invalid input. Please enter either 1 or 0 for used: ";
        cin.clear();                                         // Очистка потока ввода
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Игнорирование неверного ввода
    }
    setUsed(tempUsed); // Установка флага использования
}

// Главная функция программы
int main()
{
    // Статическое выделение памяти для объектов pin и pin2 с использованием конструктора по умолчанию и с параметрами
    Pin pin;     // Создание объекта pin с использованием конструктора по умолчанию
    pin.Print(); // Вывод информации о pin

    Pin pin2(2, "Drawing", 1.3, true); // Создание объекта pin2 с передачей параметров в конструктор
    pin2.Print();                      // Вывод информации о pin2

    // Динамическое выделение памяти для объектов pin3 и pin4 с использованием конструктора по умолчанию и с параметрами
    Pin* pin3 = new Pin(); // Создание объекта pin3 с использованием конструктора по умолчанию
    pin3->Input();         // Ввод данных о pin3
    pin3->Print();         // Вывод информации о pin3
    delete pin3;           // Освобождение памяти, занятой объектом pin3

    Pin* pin4 = new Pin(3, "Map", 6.5, false); // Создание объекта pin4 с передачей параметров в конструктор
    pin4->Print();                             // Вывод информации о pin4
    delete pin4;                               // Освобождение памяти, занятой объектом pin4

    // Используем цикл для повторного выполнения программы вместо рекурсивного вызова main
    char choice;
    do
    {
        cout << "Do you want to exit? (y/n): ";
        cin >> choice;
        if (choice == 'n' || choice == 'N')
        {
            Pin* newPin = new Pin(); // Создание нового объекта Pin
            newPin->Input();         // Ввод данных для нового объекта
            newPin->Print();         // Вывод информации о новом объекте
            delete newPin;           // Освобождение памяти, занятой новым объектом
        }
    } while (choice != 'y' && choice != 'Y'); // Продолжение цикла, пока не будет введен 'y' или 'Y'

    cout << "Exiting program...";
    cout << "\nPress Enter to exit...";
    cin.ignore(); // Ожидание нажатия клавиши Enter
    cin.get();    // Удержание консоли до нажатия Enter

    return 0; // Завершение программы
}
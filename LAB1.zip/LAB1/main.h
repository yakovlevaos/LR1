﻿#ifndef LAB1_MAIN_H
#define LAB1_MAIN_H

#include <cstring> // для strncpy

class Pin {
    // Данные открытого уровня доступа
public:
    static const int MAX_LENGTH = 20; // Максимальная длина строки для поля type

    // Конструкторы и деструктор
    Pin(); // Конструктор по умолчанию
    explicit Pin(int diameter, const char* type, float needle, bool used); // Конструктор с параметрами
    ~Pin(); // Деструктор

    // Методы для работы с объектом
    void Print() const; // Вывод информации об объекте
    void Input(); // Ввод информации об объекте

    // Геттеры
    int getDiameter() const { return diameter; } // Возвращает значение диаметра
    const char* getType() const { return type; } // Возвращает строку типа
    float getNeedle() const { return needle; } // Возвращает значение иглы
    bool isUsed() const { return used; } // Возвращает значение использования

    // Сеттеры
    bool setDiameter(int newDiameter); // Устанавливает значение диаметра
    bool setType(const char* newType); // Устанавливает значение типа
    bool setNeedle(float newNeedle); // Устанавливает значение иглы
    bool setUsed(bool newUsed); // Устанавливает значение использования

    // Данные закрытого уровня доступа
private:
    int diameter; // Диаметр
    char type[MAX_LENGTH]; // Тип
    float needle; // Игла
    bool used; // Используется ли объект
};

#endif
